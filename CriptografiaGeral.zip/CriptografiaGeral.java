import java.util.*;
import java.security.*;
import javax.crypto.*;
import java.util.Base64;

public class CriptografiaGeral {

    public static void main(String[] args) throws Exception {
        Scanner input = new Scanner(System.in);
        int opcao;

        do {
            System.out.println("\n=== MENU DE CRIPTOGRAFIA ===");
            System.out.println("1 - Criptografia Simétrica (AES)");
            System.out.println("2 - Criptografia Assimétrica (RSA)");
            System.out.println("3 - Função Hash (SHA-256)");
            System.out.println("0 - Sair");
            System.out.print("Escolha uma opção: ");
            opcao = input.nextInt();
            input.nextLine(); // limpar o buffer

            switch (opcao) {
                case 1:
                    simetricaAES(input);
                    break;
                case 2:
                    assimetricaRSA(input);
                    break;
                case 3:
                    funcaoHash(input);
                    break;
                case 0:
                    System.out.println("Saindo...");
                    break;
                default:
                    System.out.println("Opção inválida!");
            }
        } while (opcao != 0);
    }

    // Criptográfia Simétrica

    public static void simetricaAES(Scanner input) throws Exception {
        System.out.print("\nDigite uma mensagem: ");
        String texto = input.nextLine();

        KeyGenerator gerador = KeyGenerator.getInstance("AES");
        gerador.init(128);
        SecretKey chave = gerador.generateKey();

        Cipher cifra = Cipher.getInstance("AES");
        cifra.init(Cipher.ENCRYPT_MODE, chave);
        byte[] criptografado = cifra.doFinal(texto.getBytes());
        String textoCriptografado = Base64.getEncoder().encodeToString(criptografado);

        cifra.init(Cipher.DECRYPT_MODE, chave);
        byte[] descriptografado = cifra.doFinal(Base64.getDecoder().decode(textoCriptografado));

        System.out.println("\n--- CRIPTOGRAFIA SIMÉTRICA (AES) ---");
        System.out.println("Texto original: " + texto);
        System.out.println("Criptografado: " + textoCriptografado);
        System.out.println("Descriptografado: " + new String(descriptografado));
    }

     // Criptográfia Assimetrica

    public static void assimetricaRSA(Scanner input) throws Exception {
        System.out.print("\nDigite uma mensagem: ");
        String texto = input.nextLine();

        KeyPairGenerator gerador = KeyPairGenerator.getInstance("RSA");
        gerador.initialize(2048);
        KeyPair par = gerador.generateKeyPair();

        Cipher cifra = Cipher.getInstance("RSA");
        cifra.init(Cipher.ENCRYPT_MODE, par.getPublic());
        byte[] criptografado = cifra.doFinal(texto.getBytes());
        String textoCriptografado = Base64.getEncoder().encodeToString(criptografado);

        cifra.init(Cipher.DECRYPT_MODE, par.getPrivate());
        byte[] descriptografado = cifra.doFinal(Base64.getDecoder().decode(textoCriptografado));

        System.out.println("\n--- CRIPTOGRAFIA ASSIMÉTRICA (RSA) ---");
        System.out.println("Texto original: " + texto);
        System.out.println("Criptografado: " + textoCriptografado);
        System.out.println("Descriptografado: " + new String(descriptografado));
    }

    // Função hash

    public static void funcaoHash(Scanner input) throws Exception {
        System.out.print("\nDigite um texto (ex: senha): ");
        String texto = input.nextLine();

        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hash = md.digest(texto.getBytes());
        String hashBase64 = Base64.getEncoder().encodeToString(hash);

        System.out.println("\n--- FUNÇÃO HASH (SHA-256) ---");
        System.out.println("Texto original: " + texto);
        System.out.println("Hash gerado: " + hashBase64);
    }
}